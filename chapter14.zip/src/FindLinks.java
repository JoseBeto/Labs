import java.util.*;
import java.util.regex.*;
import java.io.*;

public class FindLinks {

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("index.html"));
        
        Pattern linkPattern = Pattern.compile("href=\"(.*)\"");
        while (scan.hasNextLine()) {
            String line = scan.nextLine();
            Matcher matcher = linkPattern.matcher(line);
            while (matcher.find()) {
                System.out.println(matcher.group(1));
            }
        }

    }

}
